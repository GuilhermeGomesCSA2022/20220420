﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex7P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num;
            double valorkm;

            Console.Write("Qual valor de milhas maritimas você gostaria de converter em KM ?: ");
            num = double.Parse(Console.ReadLine());

            valorkm = num * 1.852;

            Console.WriteLine("O Valor  de {0} milhas maritimas, convertido em KM é {1}", num, valorkm) ;
        }
    }
}
