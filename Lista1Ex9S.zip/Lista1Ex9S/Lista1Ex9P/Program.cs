﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex9P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diametro;
            double area;

            Console.Write("Digite o valor do diametro do círculo: ");
            diametro = double.Parse(Console.ReadLine());

            area = Math.PI * Math.Pow((diametro / 2), 2);

            Console.WriteLine("O valor da área deste círculo é: {0}", area);
        }
    }
}
