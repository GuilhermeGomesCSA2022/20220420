﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex10P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cotacao;
            double valdolar;
            double resul;

            Console.Write("Digite o atual valor da cotação do dolar: R$ ");
            cotacao = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor de dólares que deseja adiquirir: ");
            valdolar = double.Parse(Console.ReadLine());

            resul = cotacao * valdolar;

            Console.WriteLine("O valor que deseja convertido em reais, é: R$ {0}", resul.ToString("C2"));
        }
    }
}
