﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex3P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diag;
            double lado;
            double area;

            Console.Write("Digite a diagonal do quadrado: ");
            diag = double.Parse(Console.ReadLine());

            lado = diag/Math.Sqrt(2);
            area = Math.Pow(lado, 2);
            Console.WriteLine("O valor da área é {0}", area);


        }
    }
}
