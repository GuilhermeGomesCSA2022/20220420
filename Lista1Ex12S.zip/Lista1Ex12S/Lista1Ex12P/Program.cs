﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex12P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val1;
            double val2;
            double val3;
            double val4;
            double val5;
            double pgmto;
            double troco;

            Console.Write("Digite o valor do 1° produto: R$");
            val1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 2° produto: R$");
            val2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 3° produto: R$");
            val3 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 4° produto: R$");
            val4 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 5° produto: R$");
            val5 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do pagamento: R$");
            pgmto = double.Parse(Console.ReadLine());

            troco = pgmto - (val1 + val2 + val3 + val4 + val5);

            Console.WriteLine("O valor do troco é R${0}", troco);
          

        }
    }
}
