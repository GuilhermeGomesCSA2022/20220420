﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex8P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double gcelsius;
            double gfahrenheit;

            Console.Write("Qual temperatura em graus celcius você gostaria de converter para graus fahrenheit ?: ");
            gcelsius = double.Parse(Console.ReadLine());

            gfahrenheit = (gcelsius * 1.8) + 32;

            Console.WriteLine("A temperatura de {0}°C, convertida em Fahrenheit é: {1}°F", gcelsius, gfahrenheit);

        }
    }
}
