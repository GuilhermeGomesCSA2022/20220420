﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex6P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num1;
            double num2;
            double mediag;

            Console.Write("Digite o primeiro valor: ");
            num1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o segundo valor: ");
            num2 = double.Parse(Console.ReadLine());

            mediag = num1 * num2;
            mediag = Math.Sqrt(mediag);

            Console.WriteLine("A media geométria desses dois valores é: {0}", mediag);

        }
    }
}
