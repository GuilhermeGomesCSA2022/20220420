﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex5P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num1;
            double num2;
            double num3;
            double num4;
            double media;

            Console.Write("Digite o primeiro valor: ");
            num1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o segundo valor: ");
            num2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o terceiro valor: ");
            num3 = double.Parse(Console.ReadLine());

            Console.Write("Digite o quarto valor: ");
            num4 = double.Parse(Console.ReadLine());

            media = (num1 + num2 + num3 + num4) / 4;

            Console.WriteLine("O valor da média aritmética destes 4 valores são: {0}", media);
        }
    }
}
