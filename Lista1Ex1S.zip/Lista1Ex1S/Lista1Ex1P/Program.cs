﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex1P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double alt;
            double area;

            Console.Write("Digite o valor da base:");
            b = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura:");
            alt = double.Parse(Console.ReadLine());

            area = b * alt;

            Console.WriteLine("O valor da área é {0}", area);
        }
    }
}
