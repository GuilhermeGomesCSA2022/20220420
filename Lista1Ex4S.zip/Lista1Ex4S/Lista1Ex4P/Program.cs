﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex4P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double alt;
            double resul;

            Console.Write("Digite o valor da base do triângulo: ");
            b = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura do triângulo: ");
            alt = double.Parse(Console.ReadLine());

            resul = (b * alt)/2;

            Console.WriteLine("O valor da área do triângulo é {0}", resul);
        }
    }
}
