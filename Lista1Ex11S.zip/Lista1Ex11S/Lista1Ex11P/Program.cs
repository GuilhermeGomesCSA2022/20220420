﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex11P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x;
            double y;
            double resul;

            Console.Write("Digite o valor de X: ");
            x = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor de Y: ");
            y = double.Parse(Console.ReadLine());

            resul = Math.Pow(x, y);

            Console.WriteLine("O valor de {0} elevado à {1} é {2}", x, y, resul);
        }
    }
}
